const hamburgerBtn = document.getElementById('hamburgerBtn');
const navMenu = document.getElementById('navMenu');

hamburgerBtn.addEventListener('click', () => {
    navMenu.classList.toggle('active');

    // Toggle hamburger/close icon
    const icon = hamburgerBtn.querySelector("i");
    if (navMenu.classList.contains('active')) {
        icon.classList.remove("fa-bars");
        icon.classList.add("fa-times");
    } else {
        icon.classList.remove("fa-times");
        icon.classList.add("fa-bars");
    }
});


// image slidebar

const images = [
  "/images/img1.jpg","/images/img2.jpg","/images/img3.jpg","/images/img4.jpg","/images/img5.jpg","/images/img6.jpg","/images/img7.jpg"
];

let currentIndex = 0;
const imgElement = document.getElementById("slider-img");
const prevBtn = document.getElementById("prev-btn");
const nextBtn = document.getElementById("next-btn");

function changeImage(index) {
  imgElement.classList.add("fade-out");

  setTimeout(() => {
    imgElement.src = images[index];
    imgElement.classList.remove("fade-out");
    imgElement.classList.add("fade-in");
  }, 300);

  setTimeout(() => {
    imgElement.classList.remove("fade-in");
  }, 800);
}

prevBtn.addEventListener("click", () => {
  currentIndex = (currentIndex - 1 + images.length) % images.length;
  changeImage(currentIndex);
});

nextBtn.addEventListener("click", () => {
  currentIndex = (currentIndex + 1) % images.length;
  changeImage(currentIndex);
});

// principal message 

/*const readMoreBtn = document.getElementById("readMoreBtn");
const messageText = document.getElementById("messageText");

const fullMessage = `
Welcome to our esteemed institution. We believe in nurturing talents and fostering
a culture of excellence among students. Our dedicated faculty and innovative curriculum
ensure that students are prepared to face global challenges with confidence. 
We focus on holistic development, encouraging not only academic achievements but also
personal growth, integrity, and social responsibility.
`;

const shortMessage = `
Our dedicated faculty and innovative curriculum ensure...
`;

readMoreBtn.addEventListener("click", () => {
  if (messageText.classList.contains("expanded")) {
    messageText.classList.remove("expanded");
    messageText.textContent = shortMessage;
    readMoreBtn.textContent = "Read More";
  } else {
    messageText.classList.add("expanded");
    messageText.textContent = fullMessage;
    readMoreBtn.textContent = "Read Less";
  }
});*/

//links 
document.querySelectorAll('.link').forEach(card => {
      card.addEventListener('pointermove', e => {
        const r = card.getBoundingClientRect();
        const x = e.clientX - r.left; const y = e.clientY - r.top;
        card.style.setProperty('--x', x + 'px');
        card.style.setProperty('--y', y + 'px');
      });
      
      // Click ripple
card.addEventListener('click', e => {
      const r = card.getBoundingClientRect();
      const ripple = document.createElement('span');
      ripple.className = 'ripple';
      ripple.style.left = (e.clientX - r.left) + 'px';
      ripple.style.top = (e.clientY - r.top) + 'px';
      
      card.appendChild(ripple);
setTimeout(() => ripple.remove(), 700);
}, { passive: true });
});

//Animations

const scrollRevealOption = {
  distance: "50px",
  origin: "bottom",
  duration: 1000,
};

ScrollReveal().reveal(".image-container", {
  ...scrollRevealOption,
});

ScrollReveal().reveal(".image", {
  ...scrollRevealOption,
  delay: 500,
});

ScrollReveal().reveal(".card", {
  ...scrollRevealOption,
  delay: 600,
});
ScrollReveal().reveal(".link", {
  ...scrollRevealOption,
  delay: 500,
});
ScrollReveal().reveal(".boxes", {
  ...scrollRevealOption,
  delay: 600,
});
ScrollReveal().reveal(".feature-box", {
  ...scrollRevealOption,
  delay: 500,
});






